window.addEventListener('DOMContentLoaded',function(ev){
/*陈巧巧*/
	var menuSliderDom = document.getElementById('menu-slider');
	var menuDom = document.getElementById('menu');
	var headerTabDoms = document.getElementsByClassName('header-tab');
	var agDoms = document.getElementsByClassName('ag');
	var headerTabsDom = Array.prototype.slice.call(headerTabDoms);
    var agDom = Array.prototype.slice.call(agDoms);
	headerTabsDom.forEach((e,i)=>{
		e.addEventListener('mouseover',function(ev){
			var sliderLeft = this.offsetLeft;
			var sliderWidth = this.offsetWidth;
			menuSliderDom.style.transition = 'all 250ms ease-in-out';
			menuSliderDom.style.left = sliderLeft + 'px';
			menuSliderDom.style.width = sliderWidth + 'px';
			agDoms[i].style.color = '#fff';
			agDom[0].style.color = '#3c3c3c';
		},false);
		e.addEventListener('mouseout',function(ev){
			var sliderWidth = this.offsetWidth;
			menuSliderDom.style.width = sliderWidth + 'px';
			agDoms[i].style.color = '#3c3c3c';
			menuSliderDom.style.left = 0;
			agDom[0].style.color = '#fff';
		},false)
	},false);
	var kyeDom = document.getElementById('kye');
	var subDom = document.getElementById('sub');
    kyeDom.onclick = function(){
    	kyeDom.style.width = 212+'px';
    	kyeDom.style.transition = 'all .3s linear'
    	kyeDom.value = '';
		subDom.style.backgroundPosition = '-86.75px -51px';
    }
    kyeDom.onblur = function(){
    	kyeDom.style.width = 130+'px';
    	kyeDom.value = '搜游戏/主播';
    	subDom.style.backgroundPosition = '-65px -51px';
    }
/*陈巧巧*/
/*金安双*/
	var playerVideoRDom = document.getElementsByClassName('player-video-r')[0];
	var styleVideoArrowDom = document.getElementsByClassName('style-video-arrow')[0];
	var shadeDoms = document.getElementsByClassName('shade');
	var smallPicLinkDoms = playerVideoRDom.getElementsByTagName('a');
	var videoSrc = document.getElementById('videoSrc');
	var playconDom = document.getElementById('play-con');//播放暂停；
	var fullscreenDom = document.getElementById('fullscreen');//全屏播放；
	var volumeiconDom = document.getElementById('volume-icon');//是否静音
	// console.log(volumeiconDom);
	var asDom = Array.prototype.slice.call(smallPicLinkDoms);
	var shadesDom = Array.prototype.slice.call(shadeDoms);
	var videoSrcs = ['video/1.mp4','video/2.mp4','video/3.mp4','video/4.mp4','video/5.mp4'];
	asDom.forEach(function(e,i,res){
		e.addEventListener('click',function(ev){
			// alert(123);
			shadesDom.forEach(function(e){
				e.className = ' pic-item';
			})
			var top = this.offsetTop;
			styleVideoArrowDom.style.top = top + 'px';
			styleVideoArrowDom.style.transition = 'top .2s linear';
			shadesDom[i].className = shadesDom[i].className.replace(' pic-item','');
			videoSrc.src = videoSrcs[i];
		},false);
	});
	playconDom.addEventListener('click',function(ev){
		// alert(123);
		if(videoSrc.paused){
			playconDom.style.background = "url('img/icon.png') no-repeat -67px -7px";
			videoSrc.play();
			playconDom.addEventListener('mouseover',function(ev){
				playconDom.style.background = "url('img/icon.png') no-repeat -97px -7px";
			},false);
			playconDom.addEventListener('mouseout',function(ev){
				playconDom.style.background = "url('img/icon.png') no-repeat -67px -7px";
			},false);

		}else{
			playconDom.style.background = "url('img/icon.png') no-repeat -6px -7px";
			videoSrc.pause();
			playconDom.addEventListener('mouseover',function(ev){
				playconDom.style.background = "url('img/icon.png') no-repeat -37px -7px";
			},false);
			playconDom.addEventListener('mouseout',function(ev){
				playconDom.style.background = "url('img/icon.png') no-repeat -6px -7px";
			},false);
		}
	},false);
	fullscreenDom.addEventListener('click',function(ev){
			videoSrc.webkitEnterFullscreen();
			return false;
	},false);
	volumeiconDom.addEventListener('click',function(ev){
		// alert(123);
		videoSrc.muted = !videoSrc.muted;
	},false);
/*金安双*/


















},false);
